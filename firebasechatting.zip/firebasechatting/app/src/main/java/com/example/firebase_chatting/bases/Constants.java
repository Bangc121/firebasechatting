package com.example.firebase_chatting.bases;

public class Constants {
    public static final String MESSAGE_TYPE_NOTICE = "notice";
    public static final String MESSAGE_TYPE_SELF = "self";
    public static final String MESSAGE_TYPE_RECEIVE = "receive";
}
